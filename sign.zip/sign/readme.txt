game.ts aantekening en uitleg 
sign.ts letterlijk kopieren naar je eigen dev folder
images direct in je images folder
style.css kopieren naar je eigen css bestand
vragen bellen kan altijd en appen ook